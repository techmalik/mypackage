This is my first package!

It is a function that performs the task of returning the top-n items in an array, in descending order.
